# Build scripts

The supplied Makefile, CI workflow, and Vivado Tcl were embedded in Word documents. Their extracted text is preserved under `docs/source-notes/`. They are not installed as active build scripts because the extracted formatting and source dependency list have not yet been verified. After linting the RTL, promote a corrected build script here and add CI.
