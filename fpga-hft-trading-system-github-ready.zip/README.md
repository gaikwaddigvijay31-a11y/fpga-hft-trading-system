# FPGA HFT Trading System

An FPGA-oriented high-frequency trading (HFT) research project containing SystemVerilog modules for market-data parsing, order-book handling, strategy logic, risk checks, order generation, and experimental inference/SmartNIC components.

> **Project status: source extraction / bring-up.** The files in this repository were recovered from the Word documents in the supplied ZIP. They have been organized into conventional source directories, but this repository has **not** yet been compiled, simulated, synthesized, or timing-closed. Module comments that state latency, clock rate, or performance are design targets/claims from the source material, not independently verified results.

## Repository layout

```text
rtl/       SystemVerilog packages and design modules
 tb/       SystemVerilog testbenches
verify/    Python reference model(s)
docs/      Notes preserved from the supplied source documents
scripts/   Reserved for validated build/synthesis scripts
```

## RTL modules recovered

| File | Main design unit |
|---|---|
| `rtl/fixed_point_pkg.sv` | `fixed_point_pkg` |
| `rtl/ema_calculator.sv` | `ema_calculator` |
| `rtl/feature_extractor.sv` | `feature_extractor` |
| `rtl/market_data_parser.sv` | `market_data_parser` |
| `rtl/speculative_parser.sv` | `speculative_parser` |
| `rtl/order_book.sv` | `order_book` |
| `rtl/cuckoo_hash_table.sv` | `cuckoo_hash_table` |
| `rtl/market_maker.sv` | `market_maker` |
| `rtl/avellaneda_stoikov.sv` | `avellaneda_stoikov` |
| `rtl/stat_arb.sv` | `stat_arb` |
| `rtl/latency_arbiter.sv` | `latency_arbiter` |
| `rtl/neural_inference.sv` | `neural_inference` |
| `rtl/transformer_attention.sv` | `transformer_attention` |
| `rtl/deterministic_wrapper.sv` | `deterministic_wrapper`, `deterministic_ai_pipeline` |
| `rtl/risk_manager.sv` | `risk_manager` |
| `rtl/order_generator.sv` | `order_generator` |
| `rtl/session_override.sv` | `session_override` |
| `rtl/trading_system_top.sv` | `trading_system_top` |
| `rtl/smartnic_top.sv` | `smartnic_top` |

Testbenches recovered: `tb/tb_trading_system.sv` and `tb/tb_smartnic.sv`.

Python reference model recovered: `verify/nn_reference.py`.

## Important caveats before treating this as production-ready

- **No verification claim:** no simulator or FPGA tool run has been completed as part of this extraction.
- **Dependencies and interfaces:** module connections and package/type dependencies must be checked against the intended top-level design.
- **Build/synthesis scripts:** the supplied Makefile, CI workflow, and Vivado script were stored in Word documents. Their extracted text is preserved under `docs/source-notes/` rather than presented as verified runnable scripts.
- **Python dependency:** the reference model imports NumPy. Install it in your Python environment with `python -m pip install numpy`.
- **Hardware results:** do not claim a specific wire-to-wire latency, 644 MHz timing closure, or FPGA resource usage until backed by simulation and Vivado implementation reports on the target part.
- **Trading safety:** this is an engineering/research codebase, not a validated exchange-connected trading system. Do not connect it to live markets without extensive protocol, risk, and hardware validation.

## Suggested validation sequence

1. Run a SystemVerilog parser/linter on `rtl/fixed_point_pkg.sv` first.
2. Lint each leaf module with its required packages and dependencies.
3. Compile and run each testbench; inspect assertions and waveform outputs.
4. Add directed tests for malformed packets, resets, backpressure, overflow, duplicate IDs, and risk-limit boundaries.
5. Run Vivado synthesis and implementation for the exact FPGA part; archive timing and utilization reports.
6. Only then publish measured latency/resource numbers in this README.

## Source provenance

Source files were extracted from the numbered `.doc` files in the user-provided `fpga-hft-trading-system-1.0.0 (1).zip`. A filename-to-document mapping is recorded in `docs/source-notes/SOURCE_MAP.md`. The extraction process does not intentionally redesign modules or fill in missing implementations; however, Word-to-text conversion can affect line wrapping, so source review and compilation are required.
