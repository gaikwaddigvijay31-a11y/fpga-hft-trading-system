# Source map

These mappings identify the source Word document used to recover each file. The original ZIP is not duplicated into this repository.

- `rtl/avellaneda_stoikov.sv` ← `fpga-hft-trading-system-1.0.0-4.doc` — SystemVerilog module: avellaneda_stoikov.
- `rtl/cuckoo_hash_table.sv` ← `fpga-hft-trading-system-1.0.0-5.doc` — SystemVerilog module: cuckoo_hash_table.
- `rtl/deterministic_wrapper.sv` ← `fpga-hft-trading-system-1.0.0-6.doc` — SystemVerilog modules: deterministic_wrapper and deterministic_ai_pipeline.
- `rtl/ema_calculator.sv` ← `fpga-hft-trading-system-1.0.0-7.doc` — SystemVerilog module: ema_calculator.
- `rtl/feature_extractor.sv` ← `fpga-hft-trading-system-1.0.0-8.doc` — SystemVerilog module: feature_extractor.
- `rtl/fixed_point_pkg.sv` ← `fpga-hft-trading-system-1.0.0-9.doc` — SystemVerilog package: fixed_point_pkg.
- `rtl/latency_arbiter.sv` ← `fpga-hft-trading-system-1.0.0-10.doc` — SystemVerilog module: latency_arbiter.
- `rtl/market_data_parser.sv` ← `fpga-hft-trading-system-1.0.0-11.doc` — SystemVerilog module: market_data_parser.
- `rtl/market_maker.sv` ← `fpga-hft-trading-system-1.0.0-12.doc` — SystemVerilog module: market_maker.
- `rtl/neural_inference.sv` ← `fpga-hft-trading-system-1.0.0-13.doc` — SystemVerilog module: neural_inference.
- `rtl/order_book.sv` ← `fpga-hft-trading-system-1.0.0-14.doc` — SystemVerilog module: order_book.
- `rtl/order_generator.sv` ← `fpga-hft-trading-system-1.0.0-15.doc` — SystemVerilog module: order_generator.
- `rtl/risk_manager.sv` ← `fpga-hft-trading-system-1.0.0-16.doc` — SystemVerilog module: risk_manager.
- `rtl/session_override.sv` ← `fpga-hft-trading-system-1.0.0-17.doc` — SystemVerilog module: session_override.
- `rtl/smartnic_top.sv` ← `fpga-hft-trading-system-1.0.0-18.doc` — SystemVerilog module: smartnic_top.
- `rtl/speculative_parser.sv` ← `fpga-hft-trading-system-1.0.0-19.doc` — SystemVerilog module: speculative_parser.
- `rtl/stat_arb.sv` ← `fpga-hft-trading-system-1.0.0-20.doc` — SystemVerilog module: stat_arb.
- `rtl/trading_system_top.sv` ← `fpga-hft-trading-system-1.0.0-21.doc` — SystemVerilog module: trading_system_top.
- `rtl/transformer_attention.sv` ← `fpga-hft-trading-system-1.0.0-22.doc` — SystemVerilog module: transformer_attention.
- `tb/tb_smartnic.sv` ← `fpga-hft-trading-system-1.0.0-24.doc` — SystemVerilog testbench: tb_smartnic.
- `tb/tb_trading_system.sv` ← `fpga-hft-trading-system-1.0.0-25.doc` — SystemVerilog testbench: tb_trading_system.
- `verify/nn_reference.py` ← `fpga-hft-trading-system-1.0.0-26.doc` — Python reference model for neural inference.
